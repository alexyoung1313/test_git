package data;

import java.util.ArrayList;

public class Tests
{
	private String title;
	private ArrayList<Files> files;
	public String getTitle()
	{
		return title;
	}
	public ArrayList<Files> getFiles()
	{
		return files;
	}
	
}
