package data;

import java.util.ArrayList;

public class Courses
{
	private String number;
	private String term;
	private String year;
	private String title;
	private String units;
	private Syllabus syllabus;
	private Schedule schedule;
	private ArrayList<Staff> staffMembers;
	private ArrayList<Meetings> meetings;
	private ArrayList<Exams> exams;
	private ArrayList<Assignments> assignments;
	
	public ArrayList<Assignments> getAssignments()
	{
		return assignments;
	}

	public String getTitle()
	{
		return title;
	}

	public Syllabus getSyllabus()
	{
		return syllabus;
	}

	public Schedule getSchedule()
	{
		return schedule;
	}

	public String getUnits()
	{
		return units;
	}
	
	public String getNumber()
	{
		return this.number;
	}
	public String getTerm()
	{
		return this.term;
	}
	public String getYear()
	{
		return this.year;
	}
	public ArrayList<Staff> getStaff()
	{
		return this.staffMembers;
	}
	public ArrayList<Meetings> getMeetings()
	{
		return this.meetings;
	}

	public ArrayList<Exams> getExams()
	{
		return exams;
	}

	
}


//number
//term
//year
//STAFF