package data;

import java.util.ArrayList;

public class Programs
{
	private ArrayList<Files> files;

	public ArrayList<Files> getFiles()
	{
		return files;
	}
}
