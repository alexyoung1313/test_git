package data;
import java.util.ArrayList;

public class Staff
{
	private String type;
	private String id;
	private Name name;
	private String email;
	private String phone;
	private String office;
	private String image;
	private ArrayList<OfficeHours> officeHours;
	
	
	public String getType()
	{
		return this.type;
	}
	public String getEmail()
	{
		return this.email;
	}
	public String getImage()
	{
		return this.image;
	}
	public String getPhone()
	{
		return this.phone;
	}
	public String getOffice()
	{
		return this.office;
	}
	public String getId()
	{
		return this.id;
	}
	public Name getName()
	{
		return this.name;
	}
	public ArrayList<OfficeHours> getOfficeHours()
	{
		return this.officeHours;
	}
	
	public void printInfo()
	{
		System.out.println("Name: " + name.getFName() + " " + name.getLName());
		System.out.println("Email: " + email);
		System.out.println("Image: " + image);
		System.out.println("Phone: " + phone);
		System.out.println("Office: " + office);
		System.out.println("Office Hours: " );
		for(int i = 0; i < officeHours.size(); i++)
			{
				OfficeHours currOfficeHour = officeHours.get(i);
				if(currOfficeHour.getDay().equals("By Appointment"))
				{
					System.out.print("By Appointment");
				}
				else
				{
					System.out.print(currOfficeHour.getDay() + " ");
				 	System.out.print(currOfficeHour.getTime().getStart() + "-" + currOfficeHour.getTime().getEnd());
				 	if(i != officeHours.size())
				 	{
				 		System.out.print(", ");
				 	}
				}
			 	
			}
		System.out.println("");
		System.out.println("");
	}

}

//type
//id
//NAME
/*email
 * image
 * phone
 * office
 * OFFICE HOURS
 * MEETINGS
 */
