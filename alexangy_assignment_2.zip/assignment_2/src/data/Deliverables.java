package data;

import java.util.ArrayList;

public class Deliverables
{
	private String number;
	private String dueDate;
	private String title;
	private String gradePercentage;
	private ArrayList<Files> files;
	
	public String getNumber()
	{
		return number;
	}
	public String getDueDate()
	{
		return dueDate;
	}
	public String getTitle()
	{
		return title;
	}
	public String getGradePercentage()
	{
		return gradePercentage;
	}
	public ArrayList<Files> getFiles()
	{
		return files;
	}
	
}