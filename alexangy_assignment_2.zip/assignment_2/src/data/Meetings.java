package data;
import java.util.ArrayList;

public class Meetings
{
	private String type;
	private String section;
	private String room;
	private ArrayList<Assistant> assistants;
	private ArrayList<MeetingPeriods> meetingPeriods;
	
	public String getType()
	{
		return this.type;
	}
	public String getSection()
	{
		return this.section;
	}
	public String getRoom()
	{
		return this.room;
	}
	public ArrayList<Assistant> getAssistant()
	{
		return this.assistants;
	}
	public ArrayList<MeetingPeriods> getMeetingPeriods()
	{
		return meetingPeriods;
	}
	
}
