package data;

import java.util.ArrayList;

public class Topics
{
	private String number;
	private String title;
	private String url;
	private String chapter;
	private ArrayList<Programs> programs;
	
	public String getNumber()
	{
		return number;
	}
	public String getTitle()
	{
		return title;
	}
	public String getUrl()
	{
		return url;
	}
	public String getChapter()
	{
		return chapter;
	}
	public ArrayList<Programs> getPrograms()
	{
		return programs;
	}
}
