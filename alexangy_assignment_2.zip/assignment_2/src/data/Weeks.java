package data;

import java.util.ArrayList;

public class Weeks
{
	private String weeks;
	private ArrayList<Labs> labs;
	private ArrayList<Lectures> lectures;
	
	public String getWeeks()
	{
		return weeks;
	}
	public ArrayList<Labs> getLabs()
	{
		return labs;
	}
	public ArrayList<Lectures> getLectures()
	{
		return lectures;
	}
	
	
	
}
