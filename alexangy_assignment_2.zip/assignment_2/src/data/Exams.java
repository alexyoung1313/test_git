package data;

import java.util.ArrayList;

public class Exams
{
	private String semester;
	private String year;
	private ArrayList<Tests> tests;
	public String getSemester()
	{
		return semester;
	}
	public String getYear()
	{
		return year;
	}
	public ArrayList<Tests> getTests()
	{
		return tests;
	}

}
