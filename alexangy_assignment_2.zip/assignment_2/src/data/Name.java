package data;

public class Name
{
	private String fname;
	private String lname;
	
	public String getFName()
	{
		return this.fname;
	}
	public String getLName()
	{
		return this.lname;
	}
	
	public String getFullName()
	{
		return this.fname + " " + this.lname;
	}
}

//fname
//lname