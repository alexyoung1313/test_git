package data;

public class MeetingPeriods
{
	private String day;
	private Time time;

	
	public MeetingPeriods(String day_, Time time_)
	{
		this.day = day_;
		this.time = time_;
		
	}
	
	public String getDay()
	{
		return this.day;
	}
	public Time getTime()
	{
		return this.time;
	}
}

//day
//time