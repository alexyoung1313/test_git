package data;

import java.util.ArrayList;

public class Lectures
{
	private String number;
	private String date;
	private String day;
	private ArrayList<Topics> topics;
	
	public String getNumber()
	{
		return number;
	}
	public String getDate()
	{
		return date;
	}
	public String getDay()
	{
		return day;
	}
	public ArrayList<Topics> getTopics()
	{
		return topics;
	}
	
	
}
