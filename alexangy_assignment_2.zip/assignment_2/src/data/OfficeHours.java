package data;

public class OfficeHours extends MeetingPeriods
{

	public OfficeHours(String day_, Time time_)
	{
		super(day_, time_);
	}

}

//day
//time
