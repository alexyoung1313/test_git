package data;
import java.util.ArrayList;

public class Assistant
{
	private String staffMemberID;
	private String name;
	
	
	public String getID()
	{
		return this.staffMemberID;
	}
	
	public String getName(ArrayList<Staff> staff)
	{
		for(int i = 0; i < staff.size(); i++)
		{
			if(this.staffMemberID.equals(staff.get(i).getId()))
			{
				this.name = (staff.get(i).getName().getFName() + " " + staff.get(i).getName().getLName());
			}
		}
		return this.name;
	}
	public String getEmail(ArrayList<Staff> staff)
	{
		String email = "";
		for(int i = 0; i < staff.size(); i++)
		{
			
			if(this.staffMemberID.equals(staff.get(i).getId()))
			{
				email = staff.get(i).getEmail();
			}
		}
		return email;
	}
	public String getImage(ArrayList<Staff> staff)
	{
		String image = "";
		for(int i = 0; i < staff.size(); i++)
		{
			
			if(this.staffMemberID.equals(staff.get(i).getId()))
			{
				image = staff.get(i).getImage();
			}
		}
		return image;
	}
}
