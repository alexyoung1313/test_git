package data;

import java.util.ArrayList;

public class Schedule
{
	private ArrayList<Textbooks> textbooks;
	private ArrayList<Weeks> weeks;
	
	public ArrayList<Textbooks> getTextbooks()
	{
		return textbooks;
	}
	public ArrayList<Weeks> getWeeks()
	{
		return weeks;
	}
}
