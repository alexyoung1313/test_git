package data;

import java.util.ArrayList;

public class Assignments
{
	private String number;
	private String assignedDate;
	private String dueDate;
	private String title;
	private String url;
	private ArrayList<Files> files;
	private ArrayList<Files> gradingCriteria;
	private String gradePercentage;
	private ArrayList<Deliverables> deliverables;
	private ArrayList<Files> solutions;
	
	public ArrayList<Files> getSolutions()
	{
		return solutions;
	}
	public ArrayList<Files> getGradingCriteria()
	{
		return gradingCriteria;
	}
	public ArrayList<Deliverables> getDeliverables()
	{
		return deliverables;
	}
	public String getAssignedDate()
	{
		return assignedDate;
	}
	public String getGradePercentage()
	{
		return gradePercentage;
	}
	public String getNumber()
	{
		return number;
	}
	public String getDueDate()
	{
		return dueDate;
	}
	public String getTitle()
	{
		return title;
	}
	public String getUrl()
	{
		return url;
	}
	public ArrayList<Files> getFiles()
	{
		return files;
	}
	
}