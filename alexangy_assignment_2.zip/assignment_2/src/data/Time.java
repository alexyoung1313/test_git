package data;

public class Time
{
	private String start;
	private String end;
	
	public Time (String start_, String end_)
	{
		this.start = start_;
		this.end = end_;
	}

	public String getStart()
	{
		return start;
	}

	public String getEnd()
	{
		return end;
	}
	
	
}
