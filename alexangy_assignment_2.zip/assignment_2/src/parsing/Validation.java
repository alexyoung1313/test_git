package parsing;

import data.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;


@WebServlet("/Validation")
public class Validation extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	private final String UPLOAD_DIRECTORY = "C:/uploads";
	   
	     @Override
	     protected void service(HttpServletRequest request, HttpServletResponse response)
	             throws ServletException, IOException 
	     {
	    	 	HttpSession session = request.getSession();
	    	 	session.setMaxInactiveInterval(60);
	    	 	Data data = null;
	       
	         //process only if its multipart content
	         if(ServletFileUpload.isMultipartContent(request))
	         {
	             try {
	               List<FileItem> items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(new ServletRequestContext(request));
	               String temp= items.get(0).getString();
	            
	                //File uploaded successfully
	              request.setAttribute("message", "File Uploaded Successfully");
	     	      //JsonReader reader = new JsonReader(new FileReader(UPLOAD_DIRECTORY + "temp"));
	       		  Gson gson = new Gson();
	       		  data = gson.fromJson(temp, Data.class);
	       		  session.setAttribute("data", data);
	             } 
	             catch (Exception ex) 
	             {
	                request.setAttribute("message", "File Upload Failed due to " + ex);
	             }          
	          
	         }
	         else
	         {
	             request.setAttribute("message",
	                                  "Sorry this Servlet only handles file upload request");
	         }

	     
	         request.getRequestDispatcher("/home.jsp").forward(request, response);
	     }
}
